<script>
	export default {
		onLaunch: function() {
			console.log('App Launch')
		},
		onShow: function() {
			console.log('App Show')
		},
		onHide: function() {
			console.log('App Hide')
		},
		onPageNotFound() {
			uni.navigateTo({
				url: "/pages/building/building",
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		}
	}
</script>

<style lang="scss">
	/*每个页面公共css */
	@import '/uni_modules/uview-ui/theme.scss'
</style>
