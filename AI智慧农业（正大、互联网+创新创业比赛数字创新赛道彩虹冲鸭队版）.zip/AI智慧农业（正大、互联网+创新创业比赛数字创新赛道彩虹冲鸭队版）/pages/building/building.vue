<template>
	<view>
		<text>当前页面正在建设</text>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		onLoad() {
			let timer = setTimeout(()=>{
				clearTimeout(timer)
				url:'/pages/index/index'
			},2000)
		},
		methods: {
			
		}
	}
</script>

<style>

</style>
