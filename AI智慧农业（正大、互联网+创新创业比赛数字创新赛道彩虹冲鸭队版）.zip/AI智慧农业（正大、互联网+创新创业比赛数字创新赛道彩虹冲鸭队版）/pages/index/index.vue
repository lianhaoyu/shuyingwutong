<template>
	<view class="content">
		<image class="logo" src="/static/LOGO.jpg"></image>
		<view class="text-area">
			<text class="title">{{title}}</text>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				title: 'AI 智慧农业（彩虹冲鸭队）'
			}
		},
		onShow() {
			console.log('Index page show')
		},
		onLoad() {
            let timer =setTimeout(()=>{
				clearTimeout(timer)
				uni.switchTab({
					url:"/pages/AI monitor/AI monitor"
				})
			},2000)
		},
		onPullDownRefresh() {
			console.log('新的内容加载中')
		},
		methods: {
			
			}
		}
</script>

<style>
	.content {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	}

	.logo {
		height: 200rpx;
		width: 200rpx;
		margin-top: 200rpx;
		margin-left: auto;
		margin-right: auto;
		margin-bottom: 50rpx;
	}

	.text-area {
		display: flex;
		justify-content: center;
	}

	.title {
		font-size: 36rpx;
		color: #8f8f94;
	}
</style>
