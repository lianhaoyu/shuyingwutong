<template>
	<view>
		<text>通讯录</text>
		<view>{{userName}}</view>
		<view>
			<button type="default" @click="login('蜡笔小新')">登录</button>
			<button type="default" @click="logout">退出</button>
		</view>
		<navigator url="/subpages/chat/chat">客户一</navigator>
	</view>
</template>

<script>
	import{
		mapState,
		mapActions
	} from 'vuex'
	export default {
		data() {
			return {
				
			}
		},
		onLoad() {
			//#ifdef APP
			alert('欢迎使用！')
			// #endif
			
			switch(uni.getSystemInfoSync().platform){
				case 'android':
				console.log('运行到Android上')
				break;
				case 'ios':
				consolle.log('运行iOS上')
				break;
				default:
				console.log('运行在开发者工具上')
				break;
			}
		},
		computed:{
		...mapState(['userName'])
		},
		methods: {
		...mapActions(['login'],'logout')
		}
	}
</script>

<style>

</style>
