<template>
	<view>
		<text>交易中心</text>
	</view>
	<navigator url="/pages/list/list">进入聊天界面</navigator>
	<Child :msg="title" @childEvent="sayHello"></Child>
</template>

<script>
	import Child from '@/components/child.vue'
	export default {
		data() {
			return {
				title:'我是父组件定义的数据信息'
			}
		},
		components:{
			Child
		},
		methods: {
			sayHello(msg){
				this.title = msg
		}
	}
	}
</script>

<style>

</style>
