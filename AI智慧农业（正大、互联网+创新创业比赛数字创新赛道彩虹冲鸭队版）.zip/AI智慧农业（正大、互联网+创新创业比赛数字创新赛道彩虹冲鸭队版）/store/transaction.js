import Vue from 'vue'
import Vues from 'vues'
Vue.use(Vues)

const store = new Vuex.store({
	state:{
		loginState: false,
		userInfo:{
			name:'未知用户',
			avatar:'/static/nopic.png',
			like: 0;
			commented: 0
		}
		userName:uni.getStorageSync('userName') ? uni.getStorageSync('userName') : '未登录用户'
	},
	getters:{
		
	},
	mutations:{
		userLogin(state,userInfo){
			state.loginState = true
			state.userInfo = userInfo
		}
		userLogout(state) {
			state.loginState = false
			state.userInfo = {
				name: '未知用户',
				avatar:'',
				like:0,
				commented:0
			}
		}
		MLOGIN(state,userName){
			uni.setStorageSync('userName',userName)
			state.userName = userName
		},
		MLOGOUT(state){
			uni.clearStorageSync()
			state.userName = '退出状态用户'
		}
	},
	actions:{
		userLoginAction(context,userInfo) {
			context.commit('userLOgin', userInfo)
		},
		userLogoutAction(context) {
			context.commit('userLogout')
		}
		login(context, userName){
			context.commit('MLOGIN', userName)
		},
		logout(context){
			context.commit('MLOGOUT')
		},
	}
})

export default store