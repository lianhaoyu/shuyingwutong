<template>
		<view class="chat-container"></view>
			
		<!——聊天列表——>
		<view class="chat-body">
			<block v-for="(item,index) in chatList" :key="index">
				<view class="chat-one" v-if="!item.isMe">
					<image class="chat-face" src="/static/top2.jpg" />
					<view class="chat-box">
					<view class="chat-sender">客户</view>
					<view class="chat-content" v-if="item.type==='txt'">{{item.content}}</view>
					<img class="chat-img" v-if="item.type === 'img'" :src="item.content" mode="widthFix"/>
					</view>
				</view>
				<view v-else class="chat-one chat-one-mine">
					<view class="chat-box">
					<view class="chat-content" v-if="item.type==='txt'">{{item.content}}</view>
					<image class="chat-img" v-if="item.type === 'img'" :src="item.content" mode="widthFix"/>
				</view>
				<img class="chat-face" src="/static/top1.jpg"/>
			</view>
		</block>
			
	</view>
		<!——聊天输入——>
	<view class="chat-footer">
		<input  class="mag-input" type="text" cursor-spacing="16" v-model="myInput"/>
		<img class="img-chose" src="\static\photo.jpg" click="choseImgAndSend"/>
		<view class="send-btn" @click="sendMsg">发送</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				chatList:[{
					isMe:false,
					type:'txt',
					content:'你好，我对你的产品十分感兴趣，我们可以聊聊吗？'
				},{
					isMe:false,
					type:'img',
					content:'/static/1.jpg'
				},{
					isMe:true,
					type:'txt',
					content:'请问你有什么需要吗？'
				},{
					isMe:true,
					type:'img',
					content:'/static/2.jpg'
				}],
				myInput:''
			}
		},
		onShow() {
			if(!!uni.getStorageSync('chatList')){
				this.chatList = JSON.parse(uni.getStorageSync('chatList'))
				uni.pageScrollTo({
					scrollTop:999999,
					duration: 0
				})
				
			}
		},
		methods: {
			choseImgAndSend(){
				uni.chooseImage({
					count:1,
					sizeType:['original','compressed'],
					sourceType:['album','camera'],
					success: res =>{
						console.log(res.tempFilePaths[0])
						
						let senMsg = {
							isMe: true,
							type:'img',
							content: res.tempFilePaths[0]
						}
						this.chatList.push(senMsg)
						
						let resMsg = {
							isMe: false,
							type:'img',
							content: res.tempFilePaths[0]
						}
						this.chatList.push(resMsg)
						
						uni.pageScrollTo({
							scrollTop:999999,
							duration: 0
						})
						
						uni.setStorageSync('chatList',JSON.stringify(this.chatList))
						}
					})
			},
			sendMsg(){
				if(!this.myInput) return
				let senMsg = {
					isMe:true,
					type:'txt',
					content:this.myInput
				}
				this.chatList.push(senMsg)
				
				let resMsg = {
					isMe:false,
					type:'txt',
					content:this.myInput
				}
				this.chatList.push(resMsg)
				
				this.myInput = ''
				uni.pageScrollTo({
					scrollTop:999999,
					duration:0
				})
				
				uni.setStorageSync('chatList',JSON.stringify(this.chatList))
			}
		}
		}
</script>

<style lang="scss" scoped>
	.container{
		background-color: #f1f1f1;
		min-height: 100px;
	}
	
	.chat-body{
		padding-bottom: 178upx;
		}
		
		.chat-time{
			text-align: center;
			color: #888;
			padding: 40upx 0 0;
		}
		.chat-one{
			display: flex;
			flex-direction: row;
			frex-wrap:wrap;
			justify-content: flex-start;
			align-items: flex-start;
			padding: 20upx 0;
		}
		
		.chat-one-mine{
			justify-content: flex-end;
		}
		
		.chat-face{
			width: calc(100% - 290upx);
			margin-left: 20upx;
			font-size: 30upx;
		}
		
		.chat-one-mine .chat-box{
			margin-right: 20upx;
		}
		
		.chat-sender{
			color: #888;
			font-size: 28upx;
			margin-top: 8upx;
			margin-bottom: 10upx;
		}
		
		.chat-content{
			background-color: #fff;
			border-radius: 5px;
		}
		
		.micon{
			margin-right: 20upx;
			color: #666;
		}
	.chat-img{
		float: left;
		max-width: 60%;
		border-radius: 5px;
	}
	.chat-one-mine .chat-img{
		float: right;
	}
	
	.chat-footer{
		width: 670upx;
		padding: 0 40upx;
		height: 120upx;
		position: fixed;
		bottom: 0;
		left: 0;
		background-color: #f1f1f1;
		display: flex;
		flex-direction: row;
		flex-wrap: wrap;
		justify-content: space-between;
		align-items: center;
		align-content: center;
		border-top: 1upx solid #ddd;
		}
		
		.msg-input{
			background-color: #fff;
			width: calc(100% - 300upx);
			height: 70upx;
			line-height: 70upx;
			font-size: 30upx;
			border-radius: 10upx;
			padding: 0 20upx;
		}
		
		.img-chose{
			height: 70upx;
			width: 70upx;
		}
		
		.send-btn{
			height: 60upx;
			line-height: 60upx;
			width: 120upx;
			text-align: center;
			background-color: green;
			color: #FFFFFF;
			border-radius: 12upx;
		}
</style>
