import App from './App'

// #ifndef VUE3
import Vue from 'vue'
import './uni.promisify.adaptor'
Vue.config.productionTip = false

import uView from 'uview-ui'
Vue.use(uView)

Vue.prototype.BasefileURL = 'http://47.115.83.135/api/v2/files'

import login from "@vue/components/login.vue"
Vue.component("login", login)

import store from '@/store/transaction.js'

App.mpType = 'app'

const app = new Vue({
	...App,
	store
})

import httpInterceptor from '@/common/util.js'
Vue.use(httpInterceptor,app)

import httpApi from '@/common/html-parser.js'
Vue.use(httpApi,app)

app.$mount()

// 调用 store vues 状态管理
import  store from '@/store/transaction.js'

if(process.env.NODE_ENV === 'development'){
	console.log('开发环境')
}else{
	console.log('生产环境')
}
			
const app = new Vue({
  ...App,
  store
})
app.$mount()
// #endif

// #ifdef VUE3
import { createSSRApp } from 'vue'
export function createApp() {
  const app = createSSRApp(App)
  return {
    app
  }
}
// #endif