<template>
	<view class="login" :class="{show:show}">
		<view class="mask" @tap="closeLogin" bind:tap="cancel" catch:touchmove="emptyHandler"></view>
		<view class="container">
			
			<view class="close-box" @tap="closeLogin" bind:tap="cancel">
				<image class="close-img" src="">
			</view>
			
			<view class="p-name" v-if="getUserInfoTag">
				AI智慧农业（彩虹冲鸭队版）欢迎你
			</view>
			<button class="submit-btn" open-type="getUserInfo" @getUserInfo="getWechatUserInfo" v-if="getUserInfoTag"></button>
				<image src="" class="wechat-img">
				<text>一键获取微信信息</text>
			</button>
			
			<u--form :model="form" ref="uForm" v-show="!getUserInfoTag">
				<u-form-item label="账号" prop="login" label-width="150" required v-if="loginType === 'pwlogin'">
					<u-input v-model="form login" placeholder='输入手机号/邮箱/昵称'/>
				</u-form-item>
				
				<u-form-item label="昵称" prop="name" label-width="150" required v-if="loginType === 'phone' || loginType === 'email'">
					<u--input v-model="form name" placeholder='2-10个字符'/>
				</u-form-item>
				
				<u-form-item label="电话" prop="phone" label-width="150" required v-if="loginType === 'phone' || loginType === 'codelogin'">
					<u--input v-model="form phone" placeholder='输入11位手机号码'/>
				</u-form-item>
				
				<u-form-item label="邮箱" prop="email" required label-width="150" v-if="loginType !== 'email'">
					<u-input v-model="form email" placeholder='输入邮箱'>
				</u-form-item>
				
				<u-form-item label="验证码" prop="code" required label-width="150" v-if="loginType !== 'pwlogin'">
					<u-input placeholder="请输入4位验证码" v-model="from.code" type="text"></u-input>
					<u-button slot="right" type="success" size="mini" @click="getCode">获取验证码</u-button>
				</u-form-item>
				
				<u-form-item label="密码" label-width="150" required prop="password" v-if="loginType !== 'pwlogin'">
					<u-input v-model="form.password" type="password" placeholder='限4-20个字符,区分大小写'/>
				</u-form-item>
				
				<u-form-item label="重复密码" required label-width="150" prop="repassword" v-if="loginType !== 'phone' || loginTypec==='email'">
					<u-input v-model="form.repassword" type="password" placeholder='再次输入密码'/>
				</u-form-item>
				<view class="btns">
					<u-button class="ubtn" @click="submit">提交</u-button>
					<u-button class="ubtn" @click="cancel">取消</u-button>
				</view>
				<view class="type">
					<u-subsection active-color="#007cba" font-size="20" height="52" :list="subsectionList" :current="0" @change="sectionChange"></u-subsection>
				</view>
			</u--form>
			
			<view class="serve-info">点击登录/注册，即表示已阅读并同意></view>
			<view class="serve-text">
				<view @tap="gotoWeb('https://uniapp.dcloud.io/component/mp-weixin-plugin')">《隐私政策》</view>
				<view @tap="gotoWeb('https://developers.weixin.qq,com/miniprogram/dev/framework')">《用户协议》</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name:"login",
		data() {
			return {
				show: true,
				getUserInfoTag: true,
				loginType: 'pwlogin',
				subsectionList: [{
					name: '密码登陆'
				},{
					name: '验证码登陆'
				},{
					name: '手机注册'
				},{
					name: '邮箱注册'
				}],
				
				form: {
					login: '',
					avatar: '',
					name: '',
					phone: '',
					email: '',
					code: '',
					password: '',
					repassword:''
				},
				
				rules: {
					login: [{
						validator: (rule,value,callback) => {
							if (this.loginType === 'pwlogin') {
								return !this.$u.test.isEmpty(value)
							} else{
								return true
							}
						},
						message: '必填 * 输入内容不许为空',
						trigger: ['change','blur'],
					}],
					
					name: [{
						asyncValidator: async (rule,value,callback) => {
							if(this.loginType === 'phone' || this.loginType === 'email') {
								let res = await this.$u.api.findUser({
									name: value
								})
								if(!!value && res.statusCode === 200) {
									callback(new Error('当前用户昵称已存在'))
								}else {
									callback()
								}
							}else {
								callback()
							}
						},
						trigger: ['blur'],
					},
					{
						validator: (rule,value,callback) => {
							if (this.loginType === 'phone' || this.loginType === 'email') {
								return this.$u.test.rangeLength(value, [2,10])
							}else{
								return true
							}
						},
						message: '必填 * 昵称长度不得小于2位大于10位',
						trigger: ['change','blur']
					}
				],
				
				phone: [{
					asyncValidator: async (rule,value,callback) => {
						if(this.loginType === 'phone') {
							let res = await this.$u.api.findUser({
								name:value
							})
							if(!!value && res.statusCode === 200) {
								callback(new Error('当前电话已注册'))
							}else{
								callback()
							}
						}else{
							callback()
						}
					}else{
						callback()
					}
				},
				trigger: ['blur'],
				},{
					validator:(rule,value,callback) => {
						if (this.loginType === 'codelogin || this.loginType === 'phone') {
							return this.$u.test.mobile(value)
						}else{
							return true
						}
					},
					message: '必填 * 手机号输入不正确',
					trigger: ['change','blue']
				}
				],
				
				email: [{
					asyncValidator: async (ruler,value,callback) => {
						if (this.loginType === 'email') {
							let res = await this.$u.api.findUser({
								name: value
							})
							if(!!value && res.statusCode === 200) {
								callback(new Error('当前邮箱已注册'));
							} else{
								callback()
							}
						}else{
							callback()
						}
					},
					trigger: ['blur'],
				},
				{
					validator: (rule,value,callback) => {
						if (this.loginType === 'email') {
							return this.$u.test.email(value)
						}else {
							return true
						}
					},
					message: '必填 * 邮箱地址输入不正确',
					trigger: ['change','blur'],
				},
			],
			
			code: [{
				validator: (rule,value,callback) => {
					if (this.loginType !== 'pwlogin') {
						reture value === '888'
					} else {
						return true
					}
				},
				message:'必填 * 验证码长度为4位',
				trigger: ['change','blur'],
			}],
			
			password: [{
				validator: (rule,value,callback) => {
					if (this.loginType !== 'codelogin') {
						return (value.length >= 4 && value.length <= 20)
					}else{
						return true
					}
				},
				message:'必填 * 请输入4-20 位密码',
				trigger: ['change','blur'],
			}],
			repassword: [{
				validator: (rule,value,callback) => {
					if (this.loginType === 'phone' || this.loginType === 'email') {
						return this.form.password === value
					} else{
						return false
					}
				},
				message:'必填 * 两次密码输入不一致',
				trigger: ['change','blur']
			}],
			}
		},
		onReady(){
			this.$refs.uForm.setRules(this.rules);
		}
		created(){
			wx.getSetting({
				success: res => {
					if(res authSetting["scope.userInfo"]){
						uni.getUserInfo({
							success: res => {
								this.getUserInfoTag = false
								this.form.login = res.userInfo.nickName
								this.form.name = res.useInfo.nickName
								this.form.avatar = res.userInfo avatarUrl
							},
							fail: () => {
								console.log('用户未授权!')
							}
						})
					},
					sectionChange(index){
						switch (index) {
							case 1:
							this.loginType = "codelogin";
							break;
							case 2:
							this.loginType = "phone";
							break;
							this.loginType = "email";
							break;
							default:
							this.loginType = "pwlogin";
							break;
						}
					},
					async getCode() {
						let pcode = await this.$u.api.getloginCode({
							phone: this.form.phone
						})
						if (!!pcode.message && pcode.message[0] === "获取成功") {
							uni.showModal({
								title: '验证码获取成功',
								content:'8888'
							})
						}else{
							uni.showModal({
								title: '验证码获取失败',
								content: pcode.errors.phone[0]
							})
						}
					},
					cancel(){
						this.form = {
							login:'',
							name:'',
							phone:'',
							email:'',
							code:'',
							password:'',
							repassword:''
						}
					},
					submit(){
						this.$refs.uForm.validate(async vaild) => {
							if(!valid) {
								uni.showToast({
									title: '请检查输入',
									icon: 'loading'
								})
								return false
							}
							switch (this.loginType) {
								case "pwlogin"
									let resa = await this.$u.api.userLogin({
										login: this.form.login,
										password: this.form.password,
									})
									if(!!resa.access_token) {
										this.loginAfter(resa.access_token)
									}else{
										uni.showModal({
											title: '登录失败',
											content: resaa.message
										})
									}
									break;
								case"phone":
								let resb = await this.$u.api.userRegister({
									name: this.form.name,
									verifiable_type: 'sms',
									verifiable_code: '8888',
									phone: this.form.phone,
									password: this.form.password
								})
								if(!!resb.token) {
									this.loginAfter(resb.token)
								}else{
									uni.showModal({
										title: '登陆失败',
										content: resb.message
									})
								}
								break;
							case "email":
								let resc = await this.$u.api.userRegister({
									name: this.form.name,
									verifiable_type: 'mail',
									verifiable_code:'8888',
									email: this.form.email,
									password: this.form.password
								})
								console.log(resc)
								if(!!resc.token) {
									this.loginAfter(resc.token)
								}else{
									uni.showModal({
										title:'登陆失败',
										content: resc.message
									})
								}
								break;
							default:
								uni.showToast({
									title:'未知用户状态',
									icon: 'loading'
								})
								break;
							}
						}
					}
				}
			})
		},
		methods:{
			closeLogin(){
				this.show = false
			},
			openLogin(){
				this.show = true
			},
			gotoWeb(url){
				wx.navigateTo({
					url:'/pages/webview/webview?url=' + encodeURI(url)
				});
			},
			getWechatUserInfo(){
				uni.getUserInfo({
					success: res => {
						this.getUserInfoTag = false
						this.form.login = res.userInfo.nickName
						this.form.name = res.userInfo.nickName
						this.form.avatar =vres.userInfo.avatarUrl
					},
					fail: () => {
						console.log('用户未授权！')
					}
				})
			},
			
			}
		}
	}
</script>

<style lang="scss scoped">
	.login{
		position: fixed;
		top: 0;
		right: 0;
		bottom: 0;
		left: 0;
		display: flex;
		align-items: flex-end;
		opacity: 0;
		transition: opacity 300, z-index 0 300;
		pointer-events: none;
		z-index: 999;
		
		&.show{
			z-index: 9999;
			opacity: 1;
			pointer-events: auto;
		}
		
		.mask{
			position: fixed;
			width:100%;
			height:100%;
			background-color: raba($color:#000000,$alpha:0.3);
		}
		
		.container{
			z-index: 999;
			display: flex;
			z-index: 9999;
			opacity: 1;
			pointer-events: auto;
		}
		
		.mask{
			position: fixed;
			width: 100%;
			height: 100%;
			background-color: rgba($color: #000000, $alpha:0.3);
		}
		
		.container{
			z-index: 999;
			display: flex;
			flex_direction: column;
			width: 100%;
			padding: 40upx 20upx;
			background-color: #f1f1f1;
			border-radius:20upx;
			align-items: center;
			position: relative;
			
			.p-name{
				margin-top: 48upx;
				font-size: 36upx;
				font-weight: normal;
			}
			
			.close-box{
				position: absolute;
				right: 32upx;
				top: 38upx;
				width: 56.56upx;
				height: 56.56upx;
				padding: 10upx;
				width: 56.56upx;
				height: 56.56upx;
				padding: 10upx;
				
				.close-img{
					width: 100%;
					height: 100%;
				}
			}
		}
		
		.header{
			display: flex;
			flex-direction: column;
			align-items: center;
			font-size: 28upx;
			
			.logo-wrap{
				width: 144upx;
				height: 144upx;
				overflow: hidden;
				border-radius: 20upx;
			}
			
			.logo{
				width: 100%;
				height: 100%;
			}
		}
		
		.info{
			color: #333;
		}
		
		.submit-btn {
			width: 642upx;
			height: 88upx;
			margin-top: 60upx;
			margin-bottom:60upx;
			border-radius: 44upx;
			display: flex;
			flex-direction: row;
			align-items: center;
			justify-content: center;
			color: #fff;
			background-color: #0046f5;
			font-size: 36upx;
			
			.wechat-img{
				width: 44upx;
				height: 34upx;
				margin: 0 18upx;
			}
		}
		
		.phone-login{
			color: #0046f5;
			font-size: 28upx;
			margin-top: 40upx;
			border: none;
			background-color: #f1f1f1;
		}
		
		.cancel-btn{
			width: 100%;
			margin-top: 60upx;
			color: #333;
			background-color: #f1f1f1;
		}
		
		.serve-info{
			font-size: 22upx;
			margin-top: 20upx;
		}
		
		.serve-text{
			display: flex;
			flex-direction: row;
			align-items: center;
			justify-content: center;
			font-size: 22upx;
			color: #6079b8;
			margin-top: 10upx;
		}
	}
	
	button::after{
		border: none;
	}
	
	.btns{
		margin-top: 20upx;
		text-align: center:
		
		.ubtn{
			display: inline-block;
			margin: 0 20upx;
		}
	}
	
	.type{
		margin-top: 80upx;
	}
</style>